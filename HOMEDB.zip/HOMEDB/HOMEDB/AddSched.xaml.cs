﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HOMEDB
{
    /// <summary>
    /// Interaction logic for AddSched.xaml
    /// </summary>
    public partial class AddSched : Window
    {
        private DBHomeDataContext db_con = new DBHomeDataContext(Properties.Settings.Default.DBHOMEConnectionString);
        private string days = "";
        private string hour = "";
        private string thingyy = "";
        List<String> list = new List<String>();
        public AddSched()
        {
            InitializeComponent();

            
            string reschoice = Static.ResChoice.Split(' ')[0];
            if (Static.addcon == 1)
            {
                selected.Margin = new Thickness(70, 70, 0, 0);
                selected.VerticalAlignment = VerticalAlignment.Top;
                selected.HorizontalAlignment = HorizontalAlignment.Left;
                foreach(var s in db_con.tbl_Schedules)
                {
                    if (s.Resident_ID == reschoice)
                    {
                        selected.Items.Add(s.Sched_ID + " " + s.Act_Name);
                        list.Add(s.Sched_ID.ToString());
                    }
                }
            }
        }

        private void close_Click(object sender, RoutedEventArgs e)
        {
            Sched sc = new Sched();
            Static.CloseArg = "SchedClose";
            sc.Show();
            this.Close();
        }

        private void butt2_Click(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.Background == Brushes.White)
                btn.Background = Brushes.LightGreen;
            else
                btn.Background = Brushes.White;
        }

        private void confirm_Click(object sender, RoutedEventArgs e)
        {

            if (Static.addcon == 0)
            {
                int counthing = 0;
                foreach (var j in db_con.tbl_Schedules)
                    counthing++;

                counthing += 1;
                string ResID = "SCHED" + counthing.ToString().PadLeft(5, '0');

                string reschoice = Static.ResChoice.Split(' ')[0];

                days = "";
                if (butt2.Background == Brushes.LightGreen)
                    days += '7';
                if (butt2_Copy.Background == Brushes.LightGreen)
                    days += '6';
                if (butt2_Copy1.Background == Brushes.LightGreen)
                    days += '5';
                if (butt2_Copy2.Background == Brushes.LightGreen)
                    days += '4';
                if (butt2_Copy3.Background == Brushes.LightGreen)
                    days += '3';
                if (butt2_Copy4.Background == Brushes.LightGreen)
                    days += '2';
                if (butt2_Copy5.Background == Brushes.LightGreen)
                    days += '1';

                db_con.SchedInsert(ResID, reschoice, DOSAGE.Text, days, ACT.Text, Convert.ToInt32(hour), TimeStart.SelectedDate, TimeEnd.SelectedDate);
                MessageBox.Show("Succesfully inserted");
                db_con.LogsInsert(Static.StaffID, "inserted a schedule.", DateTime.Now, true);
                this.Close();
            }
            else if (Static.addcon == 1)
            {

                days = "";
                if (butt2.Background == Brushes.LightGreen)
                    days += '7';
                if (butt2_Copy.Background == Brushes.LightGreen)
                    days += '6';
                if (butt2_Copy1.Background == Brushes.LightGreen)
                    days += '5';
                if (butt2_Copy2.Background == Brushes.LightGreen)
                    days += '4';
                if (butt2_Copy3.Background == Brushes.LightGreen)
                    days += '3';
                if (butt2_Copy4.Background == Brushes.LightGreen)
                    days += '2';
                if (butt2_Copy5.Background == Brushes.LightGreen)
                    days += '1';

                db_con.SchedUpdate(thingyy, days, DOSAGE.Text, ACT.Text, Convert.ToInt32(hour), TimeStart.SelectedDate, TimeEnd.SelectedDate);
                MessageBox.Show("Succesfully updated");

                db_con.LogsInsert(Static.StaffID, "updated a schedule.", DateTime.Now, true);
                this.Close();
            }
        }

        private void Gender_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var val = (ComboBoxItem)Gender.SelectedValue;
            string thing = val.Content.ToString();
            hour = thing.Split(':')[0];

        }

        private void selected_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var thing = selected.SelectedIndex.ToString();
            int thingy1 = Convert.ToInt32(thing);
            thingyy = list[thingy1];

            foreach (var s in db_con.tbl_Schedules)
            {
                if (s.Sched_ID == thingyy)
                {
                    ACT.Text = s.Act_Name;
                    DOSAGE.Text = s.Act_Dose;
                    TimeStart.SelectedDate = s.Act_Start;
                    TimeEnd.SelectedDate = s.Act_End;
                    Gender.Text = s.Act_Time.ToString();

                    char[] charArray = s.Act_Days.ToCharArray();
                    for (int z = 0; z < charArray.Length; z++)
                    {
                        switch (charArray[z])
                        {
                            case '1':
                                butt2_Copy5.Background = Brushes.LightGreen;
                                break;
                            case '2':
                                butt2_Copy4.Background = Brushes.LightGreen;
                                break;
                            case '3':
                                butt2_Copy3.Background = Brushes.LightGreen;
                                break;
                            case '4':
                                butt2_Copy2.Background = Brushes.LightGreen;
                                break;
                            case '5':
                                butt2_Copy1.Background = Brushes.LightGreen;
                                break;
                            case '6':
                                butt2_Copy.Background = Brushes.LightGreen;
                                break;
                            case '7':
                                butt2.Background = Brushes.LightGreen;
                                break;
                        }
                    }
                }
            }
        }
    }
}
