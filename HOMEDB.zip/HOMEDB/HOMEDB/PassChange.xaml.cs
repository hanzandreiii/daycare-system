﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HOMEDB
{
    /// <summary>
    /// Interaction logic for PassChange.xaml
    /// </summary>
    public partial class PassChange : Window
    {
        private DBHomeDataContext db_con = new DBHomeDataContext(Properties.Settings.Default.DBHOMEConnectionString);
        public PassChange()
        {
            InitializeComponent();

            if(Static.LogCount > 1)
                TheGrid.Background = Brushes.AliceBlue;
        }

        private void Login_Click_1(object sender, RoutedEventArgs e)
        {
            lbl1.Content = "NEW PASSWORD";
            lbl2.Content = "CONFIRM PASSWORD";


            if (user.Text.ToString() != "" && user.Text.ToString().Equals(pass.Text.ToString()))
            {
                db_con.ChangePass(Static.temp, user.Text.ToString());
                MessageBox.Show("Password changed succesfully!");
                Login lg = new Login();
                lg.Show();
                this.Close();
            }
            else
            {

                MessageBox.Show("Please make sure that both passwords match.");
                user.Text = "";
                pass.Text = "";
            }

        }
    }
}
