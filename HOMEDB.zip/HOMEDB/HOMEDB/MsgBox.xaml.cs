﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HOMEDB
{
    /// <summary>
    /// Interaction logic for MsgBox.xaml
    /// </summary>
    public partial class MsgBox : Window
    {
        public MsgBox()
        {
            InitializeComponent();
        }

        private void butt1_Click(object sender, RoutedEventArgs e)
        {
            if(Static.MsgBoxArg.Equals("prof"))
            {
                StaffProfile prof = new StaffProfile();
                prof.Show();
                this.Close();
            }
            else if (Static.MsgBoxArg.Equals("reg"))
            {
                StaffRegistry reg = new StaffRegistry();
                reg.Show();
                this.Close();
            }
        }

        private void butt2_Click(object sender, RoutedEventArgs e)
        {
            if (Static.MsgBoxArg.Equals("prof"))
            {
                Profile prof = new Profile();
                prof.Show();
                this.Close();
            }
            else if (Static.MsgBoxArg.Equals("reg"))
            {
                Registry reg = new Registry();
                reg.Show();
                this.Close();
            }
        }

        private void close_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }
    }
}
