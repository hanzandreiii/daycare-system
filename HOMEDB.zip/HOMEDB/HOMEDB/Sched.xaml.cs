﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace HOMEDB
{
    /// <summary>
    /// Interaction logic for Sched.xaml
    /// </summary>
    public partial class Sched : Window
    {
        DispatcherTimer timer = new DispatcherTimer();
        public static int timepar = 0;
        public static int daypar = 0;
        public static int temptime = 0;
        public static int timecount = 0;
        private List<string> list = new List<string>();
        private DBHomeDataContext db_con = new DBHomeDataContext(Properties.Settings.Default.DBHOMEConnectionString);

        public Sched()
        {
            InitializeComponent();

            foreach (var s in db_con.tbl_Residents)
            {
                list.Add(s.Resident_ID.ToString().Trim() + " " + s.Resident_FN.ToString().Trim() + " " + s.Resident_LN.ToString().Trim());
            }
            selected.ItemsSource = list;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            if(Static.CloseArg.Equals("SchedClose"))
            {
                Static.CloseArg = "";
                this.Close();
            }
            Clock.Content = DateTime.Now.ToString("HH : mm : ss  dddd  dd / MM / yyyy");

            Label[] boxarray = { box1, box2, box3, box4, box5, box6, box7, box8, box9, box10, box11, box12 };
            string day = DateTime.Now.ToString("dddd");
            string time = DateTime.Now.ToString("HH");
            int timenum = int.Parse(time);
            int count = 0;

            ///LABEL CHANGER
            if (timenum >= 12)
            {
                timecount = 12;
                count = 12;
                for (int x = 0; x < boxarray.Length; x++)
                {
                    
                    boxarray[x].Content = "     " + count.ToString().PadLeft(2, '0') + ":00";
                    count++;
                }
            }
            else
            {
                timecount = 0;
                count = 0;
                for (int x = 0; x < boxarray.Length; x++)
                {
                    
                    boxarray[x].Content = "     " + count.ToString().PadLeft(2, '0') + ":00";
                    count++;
                }
            }

            ///COLOR CHANGER
            switch (day)
            {
                case "Monday":
                    Static.today = 1;
                    daypar = 1;
                    break;
                case "Tuesday":
                    Static.today = 2;
                    daypar = 2;
                    break;
                case "Wednesday":
                    Static.today = 3;
                    daypar = 3;
                    break;
                case "Thursday":
                    Static.today = 4;
                    daypar = 4;
                    break;
                case "Friday":
                    Static.today = 5;
                    daypar = 5;
                    break;
                case "Saturday":
                    Static.today = 6;
                    daypar = 6;
                    break;
                case "Sunday":
                    Static.today = 7;
                    daypar = 7;
                    break;
            }

            switch (time)
            {
                case "00":
                    timepar = 1;
                    break;
                case "12":
                    timepar = 1;
                    break;
                case "01":
                    timepar = 2;
                    break;
                case "13":
                    timepar = 2;
                    break;
                case "02":
                    timepar = 3;
                    break;
                case "14":
                    timepar = 3;
                    break;
                case "03":
                    timepar = 3;
                    break;
                case "15":
                    timepar = 4;
                    break;
                case "04":
                    timepar = 4;
                    break;
                case "16":
                    timepar = 5;
                    break;
                case "05":
                    timepar = 6;
                    break;
                case "17":
                    timepar = 6;
                    break;
                case "06":
                    timepar = 7;
                    break;
                case "18":
                    timepar = 7;
                    break;
                case "07":
                    timepar = 8;
                    break;
                case "19":
                    timepar = 8;
                    break;
                case "08":
                    timepar = 9;
                    break;
                case "20":
                    timepar = 9;
                    break;
                case "09":
                    timepar = 10;
                    break;
                case "21":
                    timepar = 10;
                    break;
                case "10":
                    timepar = 11;
                    break;
                case "22":
                    timepar = 11;
                    break;
                case "11":
                    timepar = 12;
                    break;
                case "23":
                    timepar = 12;
                    break;
            }

            Static.todaytime = timepar;

            if(temptime != timepar)
            {
                btnGen();
            }
        }

        private void selected_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var val = selected.SelectedIndex;
            Static.ResChoice = list[val].ToString();
            add.IsEnabled = true;
            edit.IsEnabled = true;

            timer.Interval = new TimeSpan(0, 0, 1);
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void btnGen()
        {
            int count = 0;
            int topmarg = 160;
            string reschoice = Static.ResChoice.Split(' ')[0];

            for (int x = 1; x < 13; x++)
            {
                int leftmarg = 252;
                for (int y = 1; y < 8; y++)
                {
                    Button butt = new Button();

                    butt.Width = 224;
                    butt.Height = 60;
                    butt.Opacity = .7;
                    butt.Margin = new Thickness(leftmarg, topmarg, 0, 0);
                    butt.VerticalAlignment = VerticalAlignment.Top;
                    butt.HorizontalAlignment = HorizontalAlignment.Left;
                    butt.Name = "_" + timecount + "_" + y;

                    int buttact = 0;

                    foreach (var s in db_con.tbl_Schedules)
                    {
                        if (s.Resident_ID.Trim().ToString() == reschoice)
                        {
                            if (DateTime.Now >= s.Act_Start && DateTime.Now <= s.Act_End)
                            {
                                char[] charArray = s.Act_Days.ToCharArray();
                                for (int z = 0; z < charArray.Length; z++)
                                {
                                    string tempbox = "_" + s.Act_Time.ToString() + "_" + charArray[z].ToString();
                                    if (butt.Name == tempbox)
                                    {
                                        int thing = 0;
                                        foreach (var j in db_con.tbl_SchedLogs)
                                        {
                                            if (j.Sched_ID == s.Sched_ID && j.Date_Completed == DateTime.Today && y == j.Day)
                                            {
                                                Static.y = y; 
                                                thing++;
                                            }
                                        }
                                        if (thing == 0)
                                            buttact++;

                                    }
                                }
                            }
                        }
                    }


                    if (buttact == 1)
                        butt.Content = buttact + " ACTIVITY";
                    else if (buttact > 1)
                        butt.Content = buttact + " ACTIVITIES";

                    if (y == daypar && x == timepar)
                    {
                        butt.Background = Brushes.LightGreen;
                    }
                    else
                        butt.Background = Brushes.White;


                    butt.Click += new RoutedEventHandler(this.button_Click);

                    theGrid.Children.Add(butt);
                    leftmarg += 229;
                    count++;
                }
                topmarg += 65;
                timecount++;
            }    
        }

        private void button_Click(object sender, EventArgs e)
        {
            Button butt = sender as Button;
            string thing = butt.Name.ToString();
            Static.timechoice = thing.Split('_')[1];
            Static.daychoice = thing.Split('_')[2];
            string reschoice = Static.ResChoice.Split(' ')[0];

            if (butt.Background == Brushes.LightGreen)
                Static.listcon = 1;
            else
                Static.listcon = 0;

            SchedCompleter cp = new SchedCompleter();
            cp.Show(); 
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }

        private void add_Click(object sender, RoutedEventArgs e)
        {
            Static.addcon = 0;
            AddSched sc = new AddSched();
            sc.Show();
        }

        private void edit_Click(object sender, RoutedEventArgs e)
        {
            Static.addcon = 1;
            AddSched sc = new AddSched();
            sc.Show();
        }

        private void refresh_Click(object sender, RoutedEventArgs e)
        {
            Sched sc = new Sched();
            sc.Show();
            this.Close();
        }
    }
}
