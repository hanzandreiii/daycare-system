﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HOMEDB
{
    /// <summary>
    /// Interaction logic for SchedCompleter.xaml
    /// </summary>
    public partial class SchedCompleter : Window
    {
        private DBHomeDataContext db_con = new DBHomeDataContext(Properties.Settings.Default.DBHOMEConnectionString);
        private List<string> list = new List<string>();
        public static int daypar = 0;
        public SchedCompleter()
        {
            InitializeComponent();

            if(Static.listcon == 0)
            {
                dabox.IsEnabled = false;
                complete.IsEnabled = false;
            }
            string reschoice = Static.ResChoice.Split(' ')[0];


            foreach (var s in db_con.tbl_Schedules)
            {
                if (s.Resident_ID.Trim().ToString() == reschoice)
                {
               
                    if (DateTime.Now >= s.Act_Start && DateTime.Now <= s.Act_End)
                    {
                        
                        char[] charArray = s.Act_Days.ToCharArray();
                        for (int z = 0; z < charArray.Length; z++)
                        {

                            if (charArray[z].ToString() == Static.daychoice)
                            {

                                if (s.Act_Time.ToString() == Static.timechoice)
                                {
                                    int thing = 0;
                                    foreach (var j in db_con.tbl_SchedLogs)
                                    {
                                        if (j.Sched_ID == s.Sched_ID && DateTime.Today == j.Date_Completed && Static.y == j.Day)
                                        {
                                            thing++;
                                        }             
                                    }
                                    if(thing == 0)
                                        dabox.Items.Add(s.Sched_ID + "\t\t\t" + s.Act_Name + "\t\t\t" + s.Act_Dose);
                                }
                                
                                
                            }
                        }
                    }
                }
            }
        }

        private void cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            Static.listcon = 0;
        }

        private void complete_Click(object sender, RoutedEventArgs e)
        {
            string thing = dabox.SelectedItem.ToString();
            string thing2 = thing.Split(' ')[0];
            db_con.SchedLogsInsert(thing2, Static.StaffID, DateTime.Today, true, Static.today);
            dabox.Items.Remove(dabox.SelectedItem);
            complete.IsEnabled = false;
            Static.listcon = 0;
        }

        private void dabox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            complete.IsEnabled = true;
        }
    }
}
