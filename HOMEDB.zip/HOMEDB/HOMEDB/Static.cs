﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HOMEDB
{
    class Static
    {
        public static string MsgBoxArg = "";
        public static string CloseArg = "";
        public static int LogCon = 1;
        public static string WindowChoice = "main";
        public static string ResChoice = "";
        public static string StaffID = "";
        public static int LogCount = 0;
        public static string daychoice = "";
        public static string timechoice = "";
        public static int listcon = 0;
        public static int today = 0;
        public static int todaytime = 0;
        public static int y = 0;
        public static int addcon = 0;
        ///resident register
        public static string PFP = "";
        public static string FIRSTNAME = "";
        public static string MIDDLENAME = "";
        public static string LASTNAME = "";
        public static string SEX = "";
        public static string GENDER = "";
        public static string POSITION = "";
        public static string ADDLINE1 = "";
        public static string ADDLINE2 = "";
        public static string ALIAS = "";
        public static string LINO = "";
        public static string CITY = "";
        public static bool STATUS = true;
        public static string socstat = "";
        public static string status2 = "";
        public static string BLOODTYPE = "";
        public static string PRONOUNS = "";
        public static DateTime DOB = DateTime.Now;
        public static DateTime DOA = DateTime.Now;
        public static string CONNAME = "";
        public static string CONNO = "";
        public static string EMAIL = "";
        public static string CONGEN = "";
        public static string CONOCC = "";
        public static string LIKES = "";
        public static string DISLIKES = "";
        public static string SOCHOS = "";
        public static string temp = "";
    }
}
