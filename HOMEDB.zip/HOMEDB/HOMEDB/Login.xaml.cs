﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HOMEDB
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        private DBHomeDataContext db_con = new DBHomeDataContext(Properties.Settings.Default.DBHOMEConnectionString);

        
        public Login()
        {
            InitializeComponent();
            if (Static.LogCount > 0)
                TheGrid.Background = Brushes.AliceBlue;

        }


        private void Login_Click_1(object sender, RoutedEventArgs e)
        {
            int count = 0;
            Static.LogCount++;
            count = db_con.Login(user.Text.ToString(), pass.Text.ToString()).Count();

            if (count == 1)
            {
                if (pass.Text.ToString() == "password")
                {
                    Static.temp = user.Text.ToString();
                    PassChange ps = new PassChange();
                    ps.Show();
                    this.Close();

                }
                else
                {
                    foreach (var s in db_con.tbl_Logins)
                    {
                        if (s.Staff_ID.Trim().ToString().Equals(user.Text.ToString()))
                        {
                            Static.StaffID = s.Staff_ID.Trim().ToString();
                            switch (Static.WindowChoice)
                            {
                                case "main":
                                    if (Convert.ToInt32(s.Staff_Perms) == 1)
                                    {
                                        db_con.LogsInsert(s.Staff_ID, "succesfully logged into the program.", DateTime.Now, true);
                                        MainWindow mw = new MainWindow();
                                        mw.Show();
                                        this.Close();
                                    }
                                    else
                                    {
                                        db_con.LogsInsert(s.Staff_ID, "tried to log into the program.", DateTime.Now, false);
                                        MessageBox.Show("Not enough permissions to access this window.");
                                    }
                                    break;
                                case "resreg":
                                    if (Convert.ToInt32(s.Staff_Perms) == 1)
                                    {
                                        int counthing = 0;
                                        foreach (var j in db_con.tbl_Residents)
                                            counthing++;

                                        counthing += 1;
                                        string ResID = "RESIDENT" + counthing.ToString().PadLeft(2, '0');

                                        db_con.ResidentInsert(ResID, Static.PFP, Static.FIRSTNAME, Static.LASTNAME, Static.MIDDLENAME, Static.SEX, Static.GENDER, Static.ALIAS, Static.BLOODTYPE, Static.PRONOUNS, Static.DOB, Static.LIKES, Static.DISLIKES, Static.SOCHOS, Static.CONNAME, Static.CONNO, Static.EMAIL, Static.CONGEN, Static.CONOCC, true);
                                        db_con.LogsInsert(s.Staff_ID, "succesfully inserted data of " + ResID + " into the Resident Table.", DateTime.Now, true);
                                        MessageBox.Show("Insert Succesful! We hope you enjoy your stay, " + Static.FIRSTNAME + "!");
                                        MainWindow mw = new MainWindow();
                                        mw.Show();
                                        this.Close();
                                    }
                                    else
                                    {
                                        db_con.LogsInsert(s.Staff_ID, "tried to insert data into the Resident Table.", DateTime.Now, false);
                                        MessageBox.Show("Not enough permissions to insert data into this table.");
                                    }
                                    break;
                                case "prof":
                                    if (Convert.ToInt32(s.Staff_Perms) == 1)
                                    {
                                        Static.LogCon = 1;
                                        db_con.LogsInsert(s.Staff_ID, "logged into editable profile table.", DateTime.Now, false);
                                        Static.MsgBoxArg = "prof";
                                        MsgBox msg = new MsgBox();
                                        msg.Show();
                                        this.Close();

                                       
                                    }
                                    else
                                    {
                                        Static.LogCon = 0;
                                        db_con.LogsInsert(s.Staff_ID, "logged into uneditable profile table.", DateTime.Now, false);
                                        Static.MsgBoxArg = "prof";
                                        MsgBox msg = new MsgBox();
                                        msg.Show();
                                        this.Close();

                                    }
                                    break;
                                case "staffreg":
                                    if (Convert.ToInt32(s.Staff_Perms) == 1)
                                    {
                                        int counthing = 0;
                                        foreach (var j in db_con.tbl_Staffs)
                                            counthing++;

                                        counthing += 1;
                                        string StaffID = "STAFFNO" + counthing.ToString().PadLeft(3, '0');

                                        db_con.StaffInsert(StaffID, Static.FIRSTNAME, Static.MIDDLENAME, Static.LASTNAME, Static.POSITION, Static.LINO, Static.DOA, DateTime.Now, Static.SEX, Static.GENDER, Static.ALIAS, "B+", "EMPLOYED", Static.DOB, Static.ADDLINE1, Static.ADDLINE2, Static.CITY, Static.EMAIL, Static.CONNO, Static.PFP);
                                        db_con.LogsInsert(s.Staff_ID, "succesfully inserted data of " + StaffID + " into the Staff Table.", DateTime.Now, true);
                                        db_con.LoginInsert(StaffID, "password", Static.STATUS);
                                        MessageBox.Show("Insert Succesful! Welcome to the team, " + StaffID + " " + Static.FIRSTNAME + "! Please make sure to change your password on your next login.");
                                        MainWindow mw = new MainWindow();
                                        mw.Show();
                                        this.Close();
                                    }
                                    else
                                    {
                                        int counthing = 0;
                                        foreach (var j in db_con.tbl_Staffs)
                                            counthing++;

                                        counthing += 1;
                                        string StaffID = "STAFFNO" + counthing.ToString().PadLeft(3, '0');

                                        db_con.LogsInsert(StaffID, "tried to insert data into the Staff Table.", DateTime.Now, false);
                                        MessageBox.Show("Not enough permissions to insert data into this table.");
                                    }
                                    break;
                                case "sched":
                                    Sched sc = new Sched();
                                    sc.Show();
                                    this.Close();
                                    break;
                                case "mwsched":
                                    Static.listcon = 1;
                                    SchedCompleter scc = new SchedCompleter();
                                   
                                    scc.Show();
                                    this.Close();
                                    break;
                            }
                        }
                    }
                }
            }
            else
                MessageBox.Show("ID not registered, please try again.");
            
        }
    }
}
