﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HOMEDB
{
    /// <summary>
    /// Interaction logic for Registry.xaml
    /// </summary>
    public partial class Registry : Window
    {
        private DBHomeDataContext db_con = new DBHomeDataContext(Properties.Settings.Default.DBHOMEConnectionString);
        private static string imgsource = "";
        public Registry()
        {
            InitializeComponent();
        }

        private void cancel_Click(object sender, RoutedEventArgs e)
        {
            
                MainWindow mw = new MainWindow();
                mw.Show();
                this.Close();
            
        }


        private void imgUpload_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openDialog = new OpenFileDialog();
            openDialog.Filter = "Image files |*.bmp;*.jpg;*.png";
            openDialog.FilterIndex = 1;

            ImageBrush myBrush = new ImageBrush();
            Image image = new Image();
            myBrush.ImageSource = image.Source;

            if (openDialog.ShowDialog() == true)
            {
                imgUpload.Content = "";
                imgUpload.Background = Brushes.Transparent;
                imgsource = openDialog.FileName.ToString();
                image.Source = new BitmapImage(new Uri(openDialog.FileName));
                myBrush.ImageSource = image.Source;
                pfp.Background = myBrush;
            }
        }

        private void SEX_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var val = (ComboBoxItem)SEX.SelectedValue;
            Static.SEX = val.Content.ToString();
        }

        private void GENDER_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var val = (ComboBoxItem)GENDER.SelectedValue;
            Static.GENDER = val.Content.ToString();
        }

        private void CONGEN_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var val = (ComboBoxItem)CONGEN.SelectedValue;
            Static.CONGEN = val.Content.ToString();
        }

        private void confirm_Click(object sender, RoutedEventArgs e)
        {
            int concon = 0;
            imgUpload.Background = Brushes.Transparent;
            FIRSTNAME.Background = Brushes.LightGray;
            LASTNAME.Background = Brushes.LightGray;
            SEX.Background = Brushes.LightGray;
            GENDER.Background = Brushes.LightGray;
            BLOODTYPE.Background = Brushes.LightGray;
            PRO1.Background = Brushes.LightGray;
            PRO2.Background = Brushes.LightGray;
            DOB.Background = Brushes.LightGray;
            CONNAME.Background = Brushes.LightGray;
            CONNO.Background = Brushes.LightGray;
            EMAIL1.Background = Brushes.LightGray;
            EMAIL2.Background = Brushes.LightGray;
            CONGEN.Background = Brushes.LightGray;
            CONOCC.Background = Brushes.LightGray;
            LIKES.Background = Brushes.LightGray;
            DISLIKES.Background = Brushes.LightGray;
            SOCHOS.Background = Brushes.LightGray;
            if (FIRSTNAME.Text == "")
            {
                FIRSTNAME.Background = Brushes.PaleVioletRed;
                concon = 1;
            }
            if (LASTNAME.Text == "")
            {
                LASTNAME.Background = Brushes.PaleVioletRed;
                concon = 1;
            }
            if (SEX.SelectedItem == null)
            {
                SEX.Background = Brushes.PaleVioletRed;
                concon = 1;
            }
            if (GENDER.SelectedItem == null)
            {
                GENDER.Background = Brushes.PaleVioletRed;
                concon = 1;
            }
            if (BLOODTYPE.Text == "")
            {
                BLOODTYPE.Background = Brushes.PaleVioletRed;
                concon = 1;
            }
            if (PRO1.Text == "")
            {
                PRO1.Background = Brushes.PaleVioletRed;
                concon = 1;
            }
            if (PRO2.Text == "")
            {
                PRO2.Background = Brushes.PaleVioletRed;
                concon = 1;
            }
            if (DOB.SelectedDate > DateTime.Now || DOB.SelectedDate == null)
            {
                DOB.Background = Brushes.PaleVioletRed;
                concon = 1;
            }
            if (CONNAME.Text == "")
            {
                CONNAME.Background = Brushes.PaleVioletRed;
                concon = 1;
            }
            if (CONNO.Text == "")
            {
                CONNO.Background = Brushes.PaleVioletRed;
                concon = 1;
            }
            if (EMAIL1.Text == "")
            {
                EMAIL1.Background = Brushes.PaleVioletRed;
                concon = 1;
            }
            if (EMAIL2.Text == "")
            {
                EMAIL2.Background = Brushes.PaleVioletRed;
                concon = 1;
            }
            if (CONGEN.SelectedItem == null)
            {
                CONGEN.Background = Brushes.PaleVioletRed;
                concon = 1;
            }
            if (CONOCC.Text == "")
            {
                CONOCC.Background = Brushes.PaleVioletRed;
                concon = 1;
            }
            if (LIKES.Text == "")
            {
                LIKES.Background = Brushes.PaleVioletRed;
                concon = 1;
            }
            if (DISLIKES.Text == "")
            {
                DISLIKES.Background = Brushes.PaleVioletRed;
                concon = 1;
            }
            if (SOCHOS.Text == "")
            {
                SOCHOS.Background = Brushes.PaleVioletRed;
                concon = 1;
            }

            if (concon == 0)
            {
                Static.PFP = imgsource.ToString();
                Static.FIRSTNAME = FIRSTNAME.Text.ToString();
                Static.MIDDLENAME = MIDDLENAME.Text.ToString();
                Static.LASTNAME = LASTNAME.Text.ToString();
                Static.ALIAS = ALIAS.Text.ToString();
                Static.BLOODTYPE = BLOODTYPE.Text.ToString();
                Static.PRONOUNS = PRO1.Text.ToString() + " " + PRO2.Text.ToString() ;
                Static.DOB = DOB.SelectedDate.Value;
                Static.CONNAME = CONNAME.Text.ToString();
                Static.CONNO = CONNO.Text.ToString();
                Static.EMAIL = EMAIL1.Text.ToString() + EMAIL2.Text.ToString();
                Static.CONOCC = CONOCC.Text.ToString();
                Static.LIKES = LIKES.Text.ToString();
                Static.DISLIKES = DISLIKES.Text.ToString();
                Static.SOCHOS = SOCHOS.Text.ToString();

                if (MessageBox.Show("Are you sure you want to continue?", "!", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
                {
                    Static.WindowChoice = "resreg";
                    Login lg = new Login();
                    lg.Show();
                    this.Close();
                }

            }
            else
                MessageBox.Show("Please make sure to input the correct details on the marked boxes.");
        }

    }
}
