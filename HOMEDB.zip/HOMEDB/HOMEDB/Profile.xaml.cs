﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HOMEDB
{
    
    public partial class Profile : Window
    {
        private int editcon = 0;
        private bool statcon = true;
        private string saveBrush = "";
        private int hincon = 1;
        private int boxcon = 1;
        private string selstring = "";
        private DBHomeDataContext db_con = new DBHomeDataContext(Properties.Settings.Default.DBHOMEConnectionString);
        private List<string> list = new List<string>();
        public Profile()
        {
            InitializeComponent();
            
            foreach (var s in db_con.tbl_Residents)
            {
                 list.Add(s.Resident_ID.ToString().Trim() + " " + s.Resident_FN.ToString().Trim() + " " + s.Resident_LN.ToString().Trim());
            }
            selected.ItemsSource = list;

            

            if (Static.LogCon == 0)
                edit.IsEnabled = false;
            else
                edit.IsEnabled = true;
        }

        private void cancel_Click(object sender, RoutedEventArgs e)
        {

            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }


        private void SEX_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var val = (ComboBoxItem)SEX.SelectedValue;
            Static.SEX = val.Content.ToString();
        }

        private void GENDER_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var val = (ComboBoxItem)GENDER.SelectedValue;
            Static.GENDER = val.Content.ToString();
        }

        private void CONGEN_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var val = (ComboBoxItem)CONGEN.SelectedValue;
            Static.CONGEN = val.Content.ToString();
        }

        private void status_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var val = CONGEN.SelectedIndex;
            int con = Convert.ToInt32(val);
            if (con == 1)
                statcon = true;
            else if (con == 2) 
                statcon = false;
        }

        private void add_Click(object sender, RoutedEventArgs e)
        {
            int counthing = 0;
            foreach (var j in db_con.tbl_Hindrances)
                counthing++;

            counthing += 1;
            string ResID = "HINDRAN" + counthing.ToString().PadLeft(3, '0');

            if (hincon == 1)
                db_con.HindranceInsert(Static.ResChoice, ResID, "allergy", cause.Text, antihistamine.Text, allergydose.Text, true);
            something();
            cause.Text = "";
            antihistamine.Text = "";
            allergydose.Text = "";
        }

        private void add2_Click(object sender, RoutedEventArgs e)
        {
            int counthing = 0;
            foreach (var j in db_con.tbl_Hindrances)
                counthing++;

            counthing += 1;
            string ResID = "HINDRAN" + counthing.ToString().PadLeft(3, '0');

            if (hincon == 1)
                db_con.HindranceInsert(Static.ResChoice, ResID, "injury", medname.Text, prescription.Text, dosage2.Text, true);
            something();
            medname.Text = "";
            prescription.Text = "";
            dosage2.Text = "";
        }

        private void imgUpload_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openDialog = new OpenFileDialog();
            openDialog.Filter = "Image files |*.bmp;*.jpg;*.png";
            openDialog.FilterIndex = 1;

            ImageBrush myBrush = new ImageBrush();
            Image image = new Image();
            myBrush.ImageSource = image.Source;

            if (openDialog.ShowDialog() == true)
            {
                imgUpload.Content = "";
                imgUpload.Background = Brushes.Transparent;
                image.Source = new BitmapImage(new Uri(openDialog.FileName));
                saveBrush = openDialog.FileName.ToString();
                myBrush.ImageSource = image.Source;
                pfp.Background = myBrush;
            }
        }

        private void selected_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int val = Convert.ToInt32(selected.SelectedIndex);
            string choice = list.ElementAt(val);
            string firstWord = choice.Substring(0, choice.IndexOf(" "));
            Static.ResChoice = firstWord;
            ImageBrush myBrush = new ImageBrush();
            Image image = new Image();
            myBrush.ImageSource = image.Source;
            saveBrush = @"C:\Users\halrr\Pictures\yourmom.jpg";
            foreach (var s in db_con.tbl_Residents)
            {
                if(s.Resident_ID.ToString().Trim().Equals(firstWord))
                {
                    image.Source = new BitmapImage(new Uri(s.Resident_PFP.Trim().ToString()));
                    myBrush.ImageSource = image.Source;
                    pfp.Background = myBrush;
                    FIRSTNAME.Text = s.Resident_FN;
                    MIDDLENAME.Text = s.Resident_MN;
                    LASTNAME.Text = s.Resident_LN;
                    if (s.Resident_Sex.Trim() == "MALE")
                        SEX.Text = "MALE";
                    else if (s.Resident_Sex.Trim() == "FEMALE")
                        SEX.Text = "FEMALE";


                    if (s.Resident_Gender.Trim() == "MALE")
                        GENDER.Text = "MALE";
                    else if (s.Resident_Gender.Trim() == "FEMALE")
                        GENDER.Text = "FEMALE";
                    else
                        GENDER.Text = "OTHERS";

                    ALIAS.Text = s.Resident_Alias;
                    BLOODTYPE.Text = s.Resident_BT;
                    PRO1.Text = s.Resident_Pronouns.ToString().Split(' ').FirstOrDefault();
                    PRO2.Text = s.Resident_Pronouns.ToString().Split(' ').Skip(1).FirstOrDefault();
                    DOB.SelectedDate = s.Resident_DOB;
                    CONNAME.Text = s.Contact_Name;
                    CONNO.Text = s.Contact_No;
                    EMAIL1.Text = s.Contact_Email;

                    if (s.Contact_Gender.Trim() == "MALE")
                        CONGEN.Text = "MALE";
                    else if (s.Contact_Gender.Trim() == "FEMALE")
                        CONGEN.Text = "FEMALE";
                    else
                        CONGEN.Text = "OTHERS";

                    CONOCC.Text = s.Contact_Occupation;
                    LIKES.Text = s.Resident_Likes;
                    DISLIKES.Text = s.Resident_Dislikes;
                    SOCHOS.Text = s.Resident_SocHos;
                    IDNO.Text = s.Resident_ID;

                    if (s.Resident_Status == true)
                        status.Text = "ACTIVE";
                    else if (s.Resident_Status == false)
                        status.Text = "INACTIVE";
                }
            }
            

            something();
        }
        private void something()
        {
            allergylist.Items.Clear();
            injurylist.Items.Clear();
            foreach (var s in db_con.tbl_Hindrances)
            {
                if (s.Resident_ID == Static.ResChoice && s.Hindrance_Type.Trim() == "allergy" && s.Hindrance_Status == true)
                {
                    allergylist.Items.Add(s.Hindrance_ID.PadRight(20, ' ') + "\t" + s.Hindrance_Name.PadRight(20, ' ') + "\t" + s.Hindrance_Presc.PadRight(20, ' ') + "\t" + s.Hindrance_Dosage);
                }
            }
            foreach (var s in db_con.tbl_Hindrances)
            {
                if (s.Resident_ID == Static.ResChoice && s.Hindrance_Type.Trim() == "injury" && s.Hindrance_Status == true)
                {
                    injurylist.Items.Add(s.Hindrance_ID.PadRight(20, ' ') + "\t" + s.Hindrance_Name.PadRight(20, ' ') + "\t" + s.Hindrance_Presc.PadRight(20, ' ') + "\t" + s.Hindrance_Dosage);
                }
            }
        }

        private void edit_Click(object sender, RoutedEventArgs e)
        {
            if(editcon == 0)
            {
                edit.Content = "CONFIRM";
                imgUpload.IsEnabled = true;
                status.IsEnabled = true;
                FIRSTNAME.IsEnabled = true;
                MIDDLENAME.IsEnabled = true;
                LASTNAME.IsEnabled = true; 
                GENDER.IsEnabled = true;
                ALIAS.IsEnabled = true;
                pfp.IsEnabled = true;
                PRO1.IsEnabled = true;
                PRO2.IsEnabled = true;
                CONNAME.IsEnabled = true;
                CONNO.IsEnabled = true;
                EMAIL1.IsEnabled = true;
                CONGEN.IsEnabled = true;
                CONOCC.IsEnabled = true;
                LIKES.IsEnabled = true;
                DISLIKES.IsEnabled = true;  
                SOCHOS.IsEnabled = true;
                status.IsEnabled = true;

                editcon = 1;
            }
            else if(editcon == 1)
            {
                int concon = 0;
                imgUpload.Background = Brushes.Transparent;
                FIRSTNAME.Background = Brushes.LightGray;
                LASTNAME.Background = Brushes.LightGray;
                GENDER.Background = Brushes.LightGray;
                BLOODTYPE.Background = Brushes.LightGray;
                PRO1.Background = Brushes.LightGray;
                PRO2.Background = Brushes.LightGray;
                DOB.Background = Brushes.LightGray;
                CONNAME.Background = Brushes.LightGray;
                CONNO.Background = Brushes.LightGray;
                EMAIL1.Background = Brushes.LightGray;
                CONGEN.Background = Brushes.LightGray;
                CONOCC.Background = Brushes.LightGray;
                LIKES.Background = Brushes.LightGray;
                DISLIKES.Background = Brushes.LightGray;
                SOCHOS.Background = Brushes.LightGray;
                if (FIRSTNAME.Text == "")
                {
                    FIRSTNAME.Background = Brushes.PaleVioletRed;
                    concon = 1;
                }
                if (LASTNAME.Text == "")
                {
                    LASTNAME.Background = Brushes.PaleVioletRed;
                    concon = 1;
                }
                if (GENDER.SelectedItem == null)
                {
                    GENDER.Background = Brushes.PaleVioletRed;
                    concon = 1;
                }
                if (BLOODTYPE.Text == "")
                {
                    BLOODTYPE.Background = Brushes.PaleVioletRed;
                    concon = 1;
                }
                if (PRO1.Text == "")
                {
                    PRO1.Background = Brushes.PaleVioletRed;
                    concon = 1;
                }
                if (PRO2.Text == "")
                {
                    PRO2.Background = Brushes.PaleVioletRed;
                    concon = 1;
                }
                if (DOB.SelectedDate > DateTime.Now || DOB.SelectedDate == null)
                {
                    DOB.Background = Brushes.PaleVioletRed;
                    concon = 1;
                }
                if (CONNAME.Text == "")
                {
                    CONNAME.Background = Brushes.PaleVioletRed;
                    concon = 1;
                }
                if (CONNO.Text == "")
                {
                    CONNO.Background = Brushes.PaleVioletRed;
                    concon = 1;
                }
                if (EMAIL1.Text == "")
                {
                    EMAIL1.Background = Brushes.PaleVioletRed;
                    concon = 1;
                }
                if (CONGEN.SelectedItem == null)
                {
                    CONGEN.Background = Brushes.PaleVioletRed;
                    concon = 1;
                }
                if (CONOCC.Text == "")
                {
                    CONOCC.Background = Brushes.PaleVioletRed;
                    concon = 1;
                }
                if (LIKES.Text == "")
                {
                    LIKES.Background = Brushes.PaleVioletRed;
                    concon = 1;
                }
                if (DISLIKES.Text == "")
                {
                    DISLIKES.Background = Brushes.PaleVioletRed;
                    concon = 1;
                }
                if (SOCHOS.Text == "")
                {
                    SOCHOS.Background = Brushes.PaleVioletRed;
                    concon = 1;
                }

                if (concon == 0)
                {
                    string pronouns = PRO1.Text + " " + PRO2.Text;

                    db_con.ResidentUpdate(Static.ResChoice, saveBrush, FIRSTNAME.Text, LASTNAME.Text, MIDDLENAME.Text, Static.GENDER, ALIAS.Text, pronouns, LIKES.Text, DISLIKES.Text, SOCHOS.Text, CONNAME.Text, CONNO.Text, EMAIL1.Text, Static.CONGEN, CONOCC.Text, statcon);
                    edit.Content = "EDIT";

                    db_con.LogsInsert(Static.StaffID, "succesfully edited data of " + Static.ResChoice + " in the Resident Table.", DateTime.Now, true);
                    MessageBox.Show("Edit succesful.");

                    imgUpload.IsEnabled = false;
                    status.IsEnabled = false;
                    FIRSTNAME.IsEnabled = false;
                    MIDDLENAME.IsEnabled = false;
                    LASTNAME.IsEnabled = false;
                    SEX.IsEnabled = false;
                    GENDER.IsEnabled = false;
                    ALIAS.IsEnabled = false;
                    pfp.IsEnabled = false;
                    PRO1.IsEnabled = false;
                    PRO2.IsEnabled = false;
                    CONNAME.IsEnabled = false;
                    CONNO.IsEnabled = false;
                    EMAIL1.IsEnabled = false;
                    CONGEN.IsEnabled = false;
                    CONOCC.IsEnabled = false;
                    LIKES.IsEnabled = false;
                    DISLIKES.IsEnabled = false;
                    SOCHOS.IsEnabled = false;

                    editcon = 0;
                }
            }
        }

        

        private void allergylist_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var allergy = allergylist.SelectedItem;
            if (allergy != null)
            {
                string thing = allergy.ToString();
                selstring = thing.Split(' ')[0];
                boxcon = 1;
                add_Copy1.IsEnabled = true;
            }
        }

        private void injurylist_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var injury = injurylist.SelectedItem;
            if (injury != null)
            {
                string thing = injury.ToString();
                selstring = thing.Split(' ')[0];
                boxcon = 1;
                add_Copy2.IsEnabled = true;
            }
        }

        private void remove_Click(object sender, RoutedEventArgs e)
        {
            db_con.HindranceUpdate(selstring, false);
            add_Copy2.IsEnabled = false;
            add_Copy2.IsEnabled = false;
            something();
            
        }

        private void refresh_Click(object sender, RoutedEventArgs e)
        {
            something();
        }
    }
}
