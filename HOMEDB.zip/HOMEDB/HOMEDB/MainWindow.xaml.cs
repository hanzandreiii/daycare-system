﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace HOMEDB
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private DBHomeDataContext db_con = new DBHomeDataContext(Properties.Settings.Default.DBHOMEConnectionString);
        private List<string> list = new List<string>();
        DispatcherTimer timer = new DispatcherTimer();

        public MainWindow()
        {
            InitializeComponent();

            timer.Interval = new TimeSpan(0, 0, 1);
            timer.Tick += Timer_Tick;
            timer.Start();

            string day = DateTime.Now.ToString("dddd");
            string time = DateTime.Now.ToString("HH");
            int timepar = 0;
            int daypar = 0;
            int somenum = 0;
            int someothernum = 0;

            switch (day)
            {
                case "Monday":
                    Static.today = 1;
                    daypar = 1;
                    break;
                case "Tuesday":
                    Static.today = 2;
                    daypar = 2;
                    break;
                case "Wednesday":
                    Static.today = 3;
                    daypar = 3;
                    break;
                case "Thursday":
                    Static.today = 4;
                    daypar = 4;
                    break;
                case "Friday":
                    Static.today = 5;
                    daypar = 5;
                    break;
                case "Saturday":
                    Static.today = 6;
                    daypar = 6;
                    break;
                case "Sunday":
                    Static.today = 7;
                    daypar = 7;
                    break;
            }

            switch (time)
            {
                case "00":
                    timepar = 1;
                    break;
                case "12":
                    timepar = 1;
                    break;
                case "01":
                    timepar = 2;
                    break;
                case "13":
                    timepar = 2;
                    break;
                case "02":
                    timepar = 3;
                    break;
                case "14":
                    timepar = 3;
                    break;
                case "03":
                    timepar = 3;
                    break;
                case "15":
                    timepar = 4;
                    break;
                case "04":
                    timepar = 4;
                    break;
                case "16":
                    timepar = 5;
                    break;
                case "05":
                    timepar = 6;
                    break;
                case "17":
                    timepar = 6;
                    break;
                case "06":
                    timepar = 7;
                    break;
                case "18":
                    timepar = 7;
                    break;
                case "07":
                    timepar = 8;
                    break;
                case "19":
                    timepar = 8;
                    break;
                case "08":
                    timepar = 9;
                    break;
                case "20":
                    timepar = 9;
                    break;
                case "09":
                    timepar = 10;
                    break;
                case "21":
                    timepar = 10;
                    break;
                case "10":
                    timepar = 11;
                    break;
                case "22":
                    timepar = 11;
                    break;
                case "11":
                    timepar = 12;
                    break;
                case "23":
                    timepar = 12;
                    break;
            }


            Static.daychoice = daypar.ToString();
            Static.timechoice = time.ToString();
            Static.y = daypar;

            foreach (var s in db_con.tbl_Schedules)
            {
                if (DateTime.Now >= s.Act_Start && DateTime.Now <= s.Act_End)
                {
                    char[] charArray = s.Act_Days.ToCharArray();
                    for (int z = 0; z < charArray.Length; z++)
                    {
                        string thingy = charArray[z].ToString();
                        Int32.TryParse(thingy, out somenum);
                        if (daypar == somenum)
                        {
                            Int32.TryParse(s.Act_Time.ToString(), out someothernum);
                            if (Convert.ToInt32(time) == someothernum)
                            {
                                int thing = 0;
                                foreach (var j in db_con.tbl_SchedLogs)
                                {
                                    if (j.Sched_ID == s.Sched_ID && DateTime.Today == j.Date_Completed && daypar == j.Day)
                                    {
                                        thing++;
                                    }

                                }
                                if (thing == 0)
                                {

                                    foreach (var o in db_con.tbl_Residents)
                                    {
                                        if (o.Resident_ID == s.Resident_ID)
                                            dabox.Items.Add(s.Resident_ID.PadRight(20, ' ') + "" + o.Resident_LN + ", " + o.Resident_FN.PadRight(40, ' ') + "" + s.Sched_ID + "      -     " + s.Act_Name);
                                    }

                                }
                            }
                            else if (someothernum < timepar)
                            {
                                int thing = 0;
                                foreach (var j in db_con.tbl_SchedLogs)
                                {
                                    if (j.Sched_ID == s.Sched_ID && DateTime.Today == j.Date_Completed && Static.y == j.Day)
                                    {
                                        thing++;
                                    }
                                }
                                if (thing == 0)
                                {
                                    db_con.SchedLogsInsert(s.Sched_ID, Static.StaffID, DateTime.Today, false, Static.today);
                                }
                            }
                        }
                    }
                }

            }
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            Clock.Content = DateTime.Now.ToString("HH : mm : ss  dddd  dd / MM / yyyy");
        }

            private void prof_Click(object sender, RoutedEventArgs e)
        {
            Static.WindowChoice = "prof";
            Login lg = new Login();
            lg.Show();
            this.Close();
        }

        private void sched_Click(object sender, RoutedEventArgs e)
        {
            Static.WindowChoice = "sched";
            Login lg = new Login();
            lg.Show();
            this.Close();
        }

        private void insert_Click(object sender, RoutedEventArgs e)
        {
            Static.MsgBoxArg = "reg";
            MsgBox msg = new MsgBox();
            msg.Show();
            this.Close();
        }

        private void logout_Click(object sender, RoutedEventArgs e)
        {
            Login lg = new Login();
            lg.Show();
            this.Close();
        }

        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string thing = dabox.SelectedItem.ToString();
            Static.ResChoice = thing.Split(' ')[0];
        }

        private void go_Click(object sender, RoutedEventArgs e)
        {
            Static.WindowChoice = "mwsched";
            Static.LogCount = 0;
            Login lg = new Login();
            lg.Show();
        }

        private void refresh_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }

        private void logs_Click(object sender, RoutedEventArgs e)
        {
            Logs lg = new Logs();
            lg.Show();
        }
    }
}
