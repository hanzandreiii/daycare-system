﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HOMEDB
{
    /// <summary>
    /// Interaction logic for StaffProfile.xaml
    /// </summary>
    public partial class StaffProfile : Window
    {
        private int editcon = 0;
        private bool statcon = true;
        private string saveBrush = "";
        private DBHomeDataContext db_con = new DBHomeDataContext(Properties.Settings.Default.DBHOMEConnectionString);
        private List<string> list = new List<string>();
        public StaffProfile()
        {
            InitializeComponent();

            foreach (var s in db_con.tbl_Staffs)
            {
                if(s.Staff_ID.Trim().ToString() != "ADMIN")
                    list.Add(s.Staff_ID.ToString().Trim() + " " + s.Staff_FN.ToString().Trim() + " " + s.Staff_LN.ToString().Trim());
            }
            selected.ItemsSource = list;

            if (Static.LogCon == 0)
                edit.IsEnabled = false;
            else
                edit.IsEnabled = true;
        }

        private void imgUpload_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openDialog = new OpenFileDialog();
            openDialog.Filter = "Image files |*.bmp;*.jpg;*.png";
            openDialog.FilterIndex = 1;

            ImageBrush myBrush = new ImageBrush();
            Image image = new Image();
            myBrush.ImageSource = image.Source;

            if (openDialog.ShowDialog() == true)
            {
                imgUpload.Content = "";
                imgUpload.Background = Brushes.Transparent;
                image.Source = new BitmapImage(new Uri(openDialog.FileName));
                saveBrush = openDialog.FileName.ToString();
                myBrush.ImageSource = image.Source;
                pfp.Background = myBrush;
            }
        }

        private void confirm_Click(object sender, RoutedEventArgs e)
        {
            if (editcon == 0)
            {
                edit.Content = "CONFIRM";
                imgUpload.IsEnabled = true;
                status.IsEnabled = true;
                FIRSTNAME.IsEnabled = true;
                MIDDLENAME.IsEnabled = true;
                LASTNAME.IsEnabled = true;
                GENDER.IsEnabled = true;
                ALIAS.IsEnabled = true;
                pfp.IsEnabled = true;
                ADDLINE1.IsEnabled = true;
                ADDLINE2.IsEnabled = true;
                CITY.IsEnabled = true;
                CONNO.IsEnabled = true;
                EMAIL.IsEnabled = true;
                position.IsEnabled = true;
                LINO.IsEnabled = true;
                DOA.IsEnabled = true;

                editcon = 1;
            }
            else if (editcon == 1)
            {
                int concon = 0;
                imgUpload.Background = Brushes.LightGray;
                status.Background = Brushes.LightGray;
                FIRSTNAME.Background = Brushes.LightGray;
                MIDDLENAME.Background = Brushes.LightGray;
                LASTNAME.Background = Brushes.LightGray;
                GENDER.Background = Brushes.LightGray;
                ALIAS.Background = Brushes.LightGray;
                pfp.Background = Brushes.LightGray;
                ADDLINE1.Background = Brushes.LightGray;
                ADDLINE2.Background = Brushes.LightGray;
                CITY.Background = Brushes.LightGray;
                CONNO.Background = Brushes.LightGray;
                EMAIL.Background = Brushes.LightGray;
                position.Background = Brushes.LightGray;
                LINO.Background = Brushes.LightGray;
                DOA.Background = Brushes.LightGray;

                if (FIRSTNAME.Text == "")
                {
                    FIRSTNAME.Background = Brushes.PaleVioletRed;
                    concon = 1;
                }
                if (LASTNAME.Text == "")
                {
                    LASTNAME.Background = Brushes.PaleVioletRed;
                    concon = 1;
                }
                if (GENDER.SelectedItem == null)
                {
                    GENDER.Background = Brushes.PaleVioletRed;
                    concon = 1;
                }
                if (ADDLINE1.Text == "")
                {
                    ADDLINE1.Background = Brushes.PaleVioletRed;
                    concon = 1;
                }
                if (ADDLINE2.Text == "")
                {
                    ADDLINE2.Background = Brushes.PaleVioletRed;
                    concon = 1;
                }
                if (CONNO.Text == "")
                {
                    CONNO.Background = Brushes.PaleVioletRed;
                    concon = 1;
                }
                if (EMAIL.Text == "")
                {
                    EMAIL.Background = Brushes.PaleVioletRed;
                    concon = 1;
                }
                if (CITY.Text == "")
                {
                    CITY.Background = Brushes.PaleVioletRed;
                    concon = 1;
                }

                if (concon == 0)
                {

                    db_con.StaffUpdate(Static.ResChoice, FIRSTNAME.Text, MIDDLENAME.Text, LASTNAME.Text, Static.POSITION, Static.STATUS, LINO.Text, DOA.SelectedDate, Static.GENDER, Static.ALIAS, Static.status2, ADDLINE1.Text, ADDLINE2.Text, CITY.Text, EMAIL.Text, CONNO.Text, saveBrush.ToString());
                    edit.Content = "EDIT";

                    db_con.LogsInsert(Static.StaffID, "succesfully edited data of " + Static.ResChoice + " in the Staff Table.", DateTime.Now, true);
                    MessageBox.Show("Edit succesful.");

                    imgUpload.IsEnabled = false;
                    status.IsEnabled = false;
                    FIRSTNAME.IsEnabled = false;
                    MIDDLENAME.IsEnabled = false;
                    LASTNAME.IsEnabled = false;
                    GENDER.IsEnabled = false;
                    ALIAS.IsEnabled = false;
                    pfp.IsEnabled = false;
                    ADDLINE1.IsEnabled = false;
                    ADDLINE2.IsEnabled = false;
                    CITY.IsEnabled = false;
                    CONNO.IsEnabled = false;
                    EMAIL.IsEnabled = false;
                    position.IsEnabled = false;
                    LINO.IsEnabled = false;
                    DOA.IsEnabled = false;

                    editcon = 0;
                }
            }
        }

        private void cancel_Click(object sender, RoutedEventArgs e)
        {

            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();

        }

        private void selected_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int val = Convert.ToInt32(selected.SelectedIndex);
            string choice = list.ElementAt(val);
            string firstWord = choice.Substring(0, choice.IndexOf(" "));
            Static.ResChoice = firstWord;
            ImageBrush myBrush = new ImageBrush();
            Image image = new Image();
            myBrush.ImageSource = image.Source;
            saveBrush = @"C:\Users\halrr\Pictures\yourmom.jpg";
            foreach (var s in db_con.tbl_Staffs)
            {
                if (s.Staff_ID.ToString().Trim().Equals(firstWord))
                {
                    image.Source = new BitmapImage(new Uri(s.Staff_PFP.Trim().ToString()));
                    myBrush.ImageSource = image.Source;
                    pfp.Background = myBrush;
                    FIRSTNAME.Text = s.Staff_FN;
                    MIDDLENAME.Text = s.Staff_MN;
                    LASTNAME.Text = s.Staff_LN;
                    if (s.Staff_Sex.Trim() == "MALE")
                        SEX.Text = "MALE";
                    else if (s.Staff_Sex.Trim() == "FEMALE")
                        SEX.Text = "FEMALE";

                    IDNO.Text = s.Staff_ID.Trim().ToString();

                    if (s.Staff_Gender.Trim() == "MALE")
                        GENDER.Text = "MALE";
                    else if (s.Staff_Gender.Trim() == "FEMALE")
                        GENDER.Text = "FEMALE";
                    else
                        GENDER.Text = "OTHERS";

                    ALIAS.Text = s.Staff_Alias;
                    BLOODTYPE.Text = s.Staff_BT;
          
                    DOB.SelectedDate = s.Staff_DOB;
                    CONNO.Text = s.Staff_Num;
                    EMAIL.Text = s.Staff_Email;

                    if (s.Staff_POS.Trim() == "ADMIN")
                        position.Text = "ADMIN";
                    else if (s.Staff_POS.Trim() == "STAFF")
                        position.Text = "STAFF";
                    else
                        position.Text = "INTERN";

                    if (s.Status.Trim() == "EMPLOYED")
                        status.Text = "EMPLOYED";
                    else if (s.Status.Trim() == "UNEMPLOYED")
                        status.Text = "UNEMPLOYED";


                    SOCSTAT.Text = "SINGLE";

                    CITY.Text = s.City;
                    ADDLINE1.Text = s.Add_One;
                    ADDLINE2.Text = s.Add_Two;
                    DOE.SelectedDate = s.Date_Emp;
                    if (s.Staff_Lino != null)
                        LINO.Text = s.Staff_Lino;

                    if (s.Date_Acq != null)
                        DOA.SelectedDate = s.Date_Acq;
                    if (s.Status == "ACTIVE")
                        status.Text = "ACTIVE";
                    else if (s.Status == "INACTIVE")
                        status.Text = "INACTIVE";
                }
            }
        }


        private void position_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var val = (ComboBoxItem)position.SelectedValue;
            if (val.Content.ToString() == "ADMIN")
                Static.STATUS = true;
            else
                Static.STATUS = false;
        }

        private void status_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var val = (ComboBoxItem)status.SelectedValue;
            Static.status2 = val.Content.ToString();
        }

        private void Gender_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var val = (ComboBoxItem)GENDER.SelectedValue;
            Static.GENDER = val.Content.ToString();
        }
    }
}
