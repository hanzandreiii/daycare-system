﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HOMEDB
{
    /// <summary>
    /// Interaction logic for Logs.xaml
    /// </summary>
    public partial class Logs : Window
    {
        private DBHomeDataContext db_con = new DBHomeDataContext(Properties.Settings.Default.DBHOMEConnectionString);
        public Logs()
        {
            InitializeComponent();
        }

        private void log_Click(object sender, RoutedEventArgs e)
        {
            dabox.Items.Clear();
            log.IsEnabled = false;
            schedlog.IsEnabled = true;
            string something = "";
            foreach(var s in db_con.tbl_Logs)
            {
                if (s.Log_Status == true)
                    something = "ATTEMPT SUCCESS";
                else
                    something = "ATTEMPT FAILED";
                dabox.Items.Add(s.Staff_ID + " - " + s.Staff_Log + "\t" + s.Log_Date + "\t" + something);
            }
        }

        private void schedlog_Click(object sender, RoutedEventArgs e)
        {
            dabox.Items.Clear();
            log.IsEnabled = true;
            schedlog.IsEnabled = false;
            string something = "";

            foreach (var s in db_con.tbl_SchedLogs)
            {
                if (s.Act_Status == true)
                    something = "TASK COMPLETED";
                else
                    something = "TASK MISSED";
                dabox.Items.Add(s.Staff_ID + " - " + s.Sched_ID + "\t" + s.Date_Completed + "\t" + something);
            }
        }

        private void cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
